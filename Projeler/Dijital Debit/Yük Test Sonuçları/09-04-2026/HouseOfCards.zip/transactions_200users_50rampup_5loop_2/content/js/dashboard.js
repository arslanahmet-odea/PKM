/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.3, "KoPercent": 0.7};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8539464285714286, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.99875, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.99875, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.999, 500, 1500, "guest-login"], "isController": false}, {"data": [0.97825, 500, 1500, "Token"], "isController": false}, {"data": [0.02625, 500, 1500, "Login"], "isController": false}, {"data": [0.858, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.992, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [1.0, 500, 1500, "Authorize"], "isController": false}, {"data": [0.1795, 500, 1500, "Transactions"], "isController": false}, {"data": [0.98525, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.99825, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.943, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.99825, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 28000, 196, 0.7, 529.3731428571389, 4, 16441, 155.0, 2142.7000000000044, 3110.9500000000007, 4258.980000000003, 338.2377811601556, 583.5457700647484, 553.9346283763379], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 2000, 0, 0.0, 144.9005000000001, 77, 640, 125.0, 215.0, 274.9499999999998, 397.99, 26.006787771608387, 7.3398063144480705, 45.26515697940912], "isController": false}, {"data": ["FailedAttempts", 2000, 0, 0.0, 94.93899999999994, 44, 627, 78.0, 146.0, 195.94999999999982, 356.97, 25.99799815414213, 9.195128889138036, 44.945397602822084], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 35.49199999999992, 15, 5036, 27.0, 47.0, 60.94999999999982, 95.99000000000001, 25.456628269585693, 32.19368516514988, 15.66830610004455], "isController": false}, {"data": ["Token", 2000, 0, 0.0, 281.7674999999998, 122, 5758, 235.5, 386.0, 467.0, 746.0, 25.995632733700738, 37.16563117396277, 45.32200211458225], "isController": false}, {"data": ["Login", 2000, 0, 0.0, 3236.6244999999967, 763, 10581, 3146.0, 4465.9000000000015, 5013.699999999999, 7665.79, 24.892340626789135, 387.5631934850521, 45.6455274298036], "isController": false}, {"data": ["SendSmsOtp", 2000, 93, 4.65, 482.91399999999953, 240, 1426, 428.0, 660.7000000000003, 1077.0, 1135.95, 25.911770421714063, 33.75691317937423, 44.82136567176265], "isController": false}, {"data": ["PairingAllowed", 2000, 0, 0.0, 160.57650000000012, 77, 1141, 133.0, 246.0, 336.7999999999993, 564.9300000000001, 26.00137807303787, 6.652696342906174, 45.23018430914339], "isController": false}, {"data": ["Authorize", 2000, 0, 0.0, 38.63450000000002, 20, 267, 35.0, 55.0, 65.0, 85.99000000000001, 26.033192320208265, 32.109298730881875, 46.838187438984704], "isController": false}, {"data": ["Transactions", 2000, 10, 0.5, 2245.314500000006, 246, 16441, 1928.0, 3718.7000000000003, 4254.849999999999, 9347.8, 25.78116943384552, 12.673345634442354, 46.306857549370946], "isController": false}, {"data": ["GetActivitionStatus", 2000, 0, 0.0, 210.0554999999998, 105, 1115, 175.0, 325.0, 431.9499999999998, 709.8800000000001, 26.001040041601662, 6.7287847763910555, 45.2042046525611], "isController": false}, {"data": ["Get Login Status", 2000, 0, 0.0, 135.32750000000001, 71, 655, 119.0, 195.0, 246.0, 381.9200000000001, 26.01084652300009, 7.417155453824244, 76.05824265437437], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 8.318000000000003, 4, 46, 8.0, 10.0, 12.0, 29.0, 25.45468429827799, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 93, 4.65, 191.26949999999945, 66, 904, 164.0, 297.9000000000001, 378.0, 619.0, 25.992929923060927, 32.399933311889164, 45.570847893435484], "isController": false}, {"data": ["CreateTimeStamp", 2000, 0, 0.0, 145.09050000000005, 79, 597, 125.0, 215.0, 276.9499999999998, 428.94000000000005, 25.993605573029033, 4.670726001403655, 46.4106562207572], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 186, 94.89795918367346, 0.6642857142857143], "isController": false}, {"data": ["500/Internal Server Error", 10, 5.1020408163265305, 0.03571428571428571], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 28000, 196, "400/Bad Request", 186, "500/Internal Server Error", 10, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["SendSmsOtp", 2000, 93, "400/Bad Request", 93, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Transactions", 2000, 10, "500/Internal Server Error", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 93, "400/Bad Request", 93, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
