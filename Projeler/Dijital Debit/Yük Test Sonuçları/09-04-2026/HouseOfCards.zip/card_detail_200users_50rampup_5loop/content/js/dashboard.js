/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.01071428571429, "KoPercent": 0.9892857142857143};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7527857142857143, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.90525, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.92525, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.9995, 500, 1500, "guest-login"], "isController": false}, {"data": [0.78975, 500, 1500, "Token"], "isController": false}, {"data": [0.02575, 500, 1500, "Login"], "isController": false}, {"data": [0.65925, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.8395, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [0.9995, 500, 1500, "Authorize"], "isController": false}, {"data": [0.791, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.92225, 500, 1500, "Get Login Status"], "isController": false}, {"data": [0.021, 500, 1500, "Kart Detay"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.75225, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.90875, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 28000, 277, 0.9892857142857143, 1140.0283928571514, 5, 56265, 218.0, 5319.700000000004, 8222.0, 11691.910000000014, 178.4507921940525, 313.6751412868214, 290.53107807182323], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 2000, 0, 0.0, 348.10750000000024, 74, 52690, 144.0, 758.8000000000002, 1032.7999999999993, 1627.89, 13.032881961188076, 3.6782254753743695, 22.68374378087164], "isController": false}, {"data": ["FailedAttempts", 2000, 0, 0.0, 262.57350000000025, 42, 52378, 82.0, 620.6000000000004, 921.8499999999995, 1685.97, 13.02897644361059, 4.539103266445826, 22.524320162259617], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 45.10399999999997, 14, 26759, 30.0, 44.0, 53.0, 81.0, 13.159626266614028, 16.64230079615739, 8.09991060707001], "isController": false}, {"data": ["Token", 2000, 0, 0.0, 691.0825000000001, 119, 52771, 265.5, 1423.7000000000003, 2121.0, 5564.92, 13.024988440322758, 18.621663160773945, 22.708514038088325], "isController": false}, {"data": ["Login", 2000, 0, 0.0, 4192.582000000009, 603, 56265, 3441.5, 7388.8, 8631.499999999998, 13344.87, 12.948168481568283, 201.59749546004844, 23.742224523669254], "isController": false}, {"data": ["SendSmsOtp", 2000, 133, 6.65, 789.623, 255, 5543, 521.0, 1541.5000000000005, 1976.7999999999993, 3026.84, 12.998238738650914, 16.684775345753152, 22.48431275062229], "isController": false}, {"data": ["PairingAllowed", 2000, 0, 0.0, 434.8240000000001, 76, 5461, 184.0, 1134.7000000000003, 1579.7999999999993, 2499.82, 13.030504410825744, 3.333976714488618, 22.667014163751094], "isController": false}, {"data": ["Authorize", 2000, 0, 0.0, 34.774499999999975, 20, 5026, 30.0, 42.0, 50.0, 67.0, 13.039679745465452, 16.083120623557488, 23.459294347543327], "isController": false}, {"data": ["GetActivitionStatus", 2000, 0, 0.0, 577.6739999999993, 104, 52694, 296.5, 1359.0, 1823.2499999999973, 2813.9300000000003, 13.030674207083475, 3.372195961794063, 22.65455881191199], "isController": false}, {"data": ["Get Login Status", 2000, 0, 0.0, 264.47850000000034, 68, 5401, 120.0, 649.8000000000002, 947.6999999999989, 1558.91, 13.020579025149248, 3.712899487640215, 38.0733873911154], "isController": false}, {"data": ["Kart Detay", 2000, 11, 0.55, 7468.483999999995, 206, 37864, 7713.5, 11267.9, 12584.64999999999, 15873.04, 12.953703463820306, 12.812812963499702, 21.521971100287573], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 8.968499999999986, 5, 50, 9.0, 11.0, 13.0, 30.99000000000001, 14.489498735791235, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 133, 6.65, 524.1144999999989, 65, 52796, 257.0, 1206.6000000000004, 1572.7999999999993, 2557.95, 13.024140243942146, 16.00145361615254, 22.83414779997851], "isController": false}, {"data": ["CreateTimeStamp", 2000, 0, 0.0, 318.00700000000074, 77, 26417, 140.5, 734.9000000000001, 1030.5999999999985, 1894.7800000000002, 13.023546572202543, 2.3401685246926442, 23.252505862630883], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 276, 99.63898916967509, 0.9857142857142858], "isController": false}, {"data": ["500/Internal Server Error", 1, 0.36101083032490977, 0.0035714285714285713], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 28000, 277, "400/Bad Request", 276, "500/Internal Server Error", 1, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["SendSmsOtp", 2000, 133, "400/Bad Request", 133, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Kart Detay", 2000, 11, "400/Bad Request", 10, "500/Internal Server Error", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 133, "400/Bad Request", 133, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
