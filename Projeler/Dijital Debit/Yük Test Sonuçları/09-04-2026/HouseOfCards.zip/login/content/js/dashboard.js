/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.99230769230769, "KoPercent": 0.007692307692307693};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9158461538461539, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.998, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.9975, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.9985, 500, 1500, "guest-login"], "isController": false}, {"data": [0.99275, 500, 1500, "Token"], "isController": false}, {"data": [0.03075, 500, 1500, "Login"], "isController": false}, {"data": [0.90475, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.9975, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [0.9995, 500, 1500, "Authorize"], "isController": false}, {"data": [0.994, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.998, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.9965, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.99825, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 26000, 2, 0.007692307692307693, 380.4151923076949, 5, 54461, 137.0, 483.0, 2675.0, 3758.0, 214.47898105985612, 391.8849190084059, 348.63929746017703], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 2000, 0, 0.0, 143.47699999999952, 80, 930, 131.0, 197.0, 234.0, 360.94000000000005, 16.855163579362536, 4.756974877378685, 29.33666734175108], "isController": false}, {"data": ["FailedAttempts", 2000, 0, 0.0, 102.93100000000011, 44, 5130, 80.5, 133.0, 164.94999999999982, 256.99, 16.867388590898358, 6.056874989457882, 29.16013220079361], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 65.36500000000005, 14, 52812, 28.0, 55.0, 70.0, 140.97000000000003, 17.029392731855182, 21.536194909914514, 10.482073504180716], "isController": false}, {"data": ["Token", 2000, 0, 0.0, 272.7720000000002, 127, 52789, 223.0, 326.9000000000001, 370.89999999999964, 536.97, 16.846361185983827, 24.085032008086255, 29.370824603057613], "isController": false}, {"data": ["Login", 2000, 0, 0.0, 2943.538000000001, 707, 54461, 2872.0, 3713.7000000000003, 4228.399999999998, 5567.64, 16.725764367431594, 260.41306235155884, 30.669522874050813], "isController": false}, {"data": ["SendSmsOtp", 2000, 1, 0.05, 500.7130000000003, 170, 52881, 423.0, 550.0, 625.0, 1111.7700000000002, 16.82312169846237, 22.663652830700514, 29.100057619191816], "isController": false}, {"data": ["PairingAllowed", 2000, 0, 0.0, 149.6834999999997, 75, 683, 135.0, 210.0, 244.0, 386.8800000000001, 16.85416930013062, 4.312297223275608, 29.319152459128638], "isController": false}, {"data": ["Authorize", 2000, 0, 0.0, 41.48649999999996, 22, 5041, 34.0, 57.0, 66.0, 106.99000000000001, 16.86710408689932, 20.803859825931486, 30.345534486902693], "isController": false}, {"data": ["GetActivitionStatus", 2000, 0, 0.0, 225.74900000000002, 104, 52734, 181.0, 268.9000000000001, 314.9499999999998, 530.99, 16.856015912079023, 4.362152555372012, 29.305607535587264], "isController": false}, {"data": ["Get Login Status", 2000, 0, 0.0, 161.84850000000029, 71, 52418, 120.0, 180.0, 208.0, 295.99, 16.866677348895657, 4.8096384627710265, 49.320058775099724], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 8.651499999999986, 5, 44, 8.0, 11.0, 13.0, 29.0, 29.27486167627858, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 1, 0.05, 182.79700000000005, 79, 5321, 167.0, 249.0, 281.0, 406.95000000000005, 16.852891113470516, 21.700434330603162, 29.54685406554932], "isController": false}, {"data": ["CreateTimeStamp", 2000, 0, 0.0, 146.38549999999967, 73, 923, 131.0, 209.0, 239.0, 378.95000000000005, 16.857720836142953, 3.0291217127444368, 30.09801184254889], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 2, 100.0, 0.007692307692307693], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 26000, 2, "400/Bad Request", 2, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["SendSmsOtp", 2000, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
