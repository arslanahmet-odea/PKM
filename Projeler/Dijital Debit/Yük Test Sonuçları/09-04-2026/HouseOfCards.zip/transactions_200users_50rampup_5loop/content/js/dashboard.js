/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.53214285714286, "KoPercent": 0.46785714285714286};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7807678571428571, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.93875, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.946, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.999, 500, 1500, "guest-login"], "isController": false}, {"data": [0.8115, 500, 1500, "Token"], "isController": false}, {"data": [0.018, 500, 1500, "Login"], "isController": false}, {"data": [0.713, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.8775, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [0.9955, 500, 1500, "Authorize"], "isController": false}, {"data": [0.07625, 500, 1500, "Transactions"], "isController": false}, {"data": [0.85125, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.9525, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.8285, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.923, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 28000, 131, 0.46785714285714286, 1092.694964285725, 5, 91436, 179.0, 2879.9000000000015, 5634.0, 11726.950000000008, 187.66881815561769, 323.1963437359667, 306.7831373178607], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 2000, 14, 0.7, 359.5980000000004, 7, 30121, 134.0, 457.60000000000036, 878.8999999999996, 1891.3400000000006, 13.987089916007525, 3.962102744791557, 24.29946807534146], "isController": false}, {"data": ["FailedAttempts", 2000, 6, 0.3, 257.84350000000023, 8, 52497, 90.0, 432.0, 795.7499999999991, 1903.2400000000007, 13.963067685970607, 4.796491015638636, 24.09379145285719], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 33.07949999999993, 14, 5025, 26.0, 39.0, 46.0, 78.0, 13.7484447071925, 17.38694911700614, 8.462671200359521], "isController": false}, {"data": ["Token", 2000, 9, 0.45, 802.3500000000014, 8, 60081, 310.0, 1394.6000000000022, 3759.6999999999407, 6894.870000000001, 13.99687869605078, 19.94984415350377, 24.357261690018124], "isController": false}, {"data": ["Login", 2000, 14, 0.7, 7532.715999999992, 638, 91436, 6067.0, 13088.1, 17329.349999999988, 36321.99, 13.591203772918167, 210.19587021717047, 24.897233775925223], "isController": false}, {"data": ["SendSmsOtp", 2000, 14, 0.7, 747.3870000000002, 9, 53858, 483.0, 1418.2000000000007, 1988.2499999999973, 2800.87, 13.937962130556892, 18.690562213836216, 24.064823991849778], "isController": false}, {"data": ["PairingAllowed", 2000, 6, 0.3, 385.73449999999985, 8, 8591, 177.0, 932.6000000000004, 1351.5999999999985, 2524.7700000000004, 13.983960397424154, 3.5844277239006863, 24.28013603552975], "isController": false}, {"data": ["Authorize", 2000, 7, 0.35, 82.96550000000003, 15, 64997, 31.0, 49.0, 58.0, 94.99000000000001, 14.010802328595346, 17.23907452958731, 25.160992875507013], "isController": false}, {"data": ["Transactions", 2000, 28, 1.4, 3108.531999999999, 49, 64998, 2655.0, 5444.100000000002, 6707.449999999994, 10972.480000000001, 13.971553916226563, 6.8910255360710595, 25.032406091510186], "isController": false}, {"data": ["GetActivitionStatus", 2000, 7, 0.35, 653.7335000000019, 9, 52771, 230.5, 1098.900000000001, 1681.699999999999, 9260.700000000017, 13.991884706870016, 3.6270340155834617, 24.280763836662235], "isController": false}, {"data": ["Get Login Status", 2000, 6, 0.3, 305.0505000000002, 14, 53156, 133.0, 425.9000000000001, 759.6999999999989, 1652.840000000001, 13.929419630731086, 3.977420628425767, 40.64065971472549], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 8.346000000000007, 5, 43, 8.0, 10.0, 12.0, 28.99000000000001, 13.747405177272789, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 14, 0.7, 511.8824999999999, 12, 26740, 242.0, 1166.8000000000002, 1640.8499999999995, 2840.760000000001, 13.97624039133473, 17.915861395003496, 24.45778602157582], "isController": false}, {"data": ["CreateTimeStamp", 2000, 6, 0.3, 508.5109999999996, 14, 53176, 136.0, 597.0, 1040.699999999999, 11981.84, 13.948071330436782, 2.5160195778616212, 24.85821458584689], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 14,522; received: 13,527)", 2, 1.5267175572519085, 0.007142857142857143], "isController": false}, {"data": ["400/Bad Request", 24, 18.3206106870229, 0.08571428571428572], "isController": false}, {"data": ["504/Gateway Time-out", 2, 1.5267175572519085, 0.007142857142857143], "isController": false}, {"data": ["500/Internal Server Error", 33, 25.19083969465649, 0.11785714285714285], "isController": false}, {"data": ["401/Unauthorized", 70, 53.43511450381679, 0.25], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 28000, 131, "401/Unauthorized", 70, "500/Internal Server Error", 33, "400/Bad Request", 24, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 14,522; received: 13,527)", 2, "504/Gateway Time-out", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["CreateActivitionToken", 2000, 14, "400/Bad Request", 8, "401/Unauthorized", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["FailedAttempts", 2000, 6, "401/Unauthorized", 6, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Token", 2000, 9, "401/Unauthorized", 7, "500/Internal Server Error", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["Login", 2000, 14, "500/Internal Server Error", 12, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 14,522; received: 13,527)", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["SendSmsOtp", 2000, 14, "400/Bad Request", 8, "401/Unauthorized", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["PairingAllowed", 2000, 6, "401/Unauthorized", 6, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Authorize", 2000, 7, "401/Unauthorized", 6, "504/Gateway Time-out", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Transactions", 2000, 28, "500/Internal Server Error", 18, "401/Unauthorized", 9, "504/Gateway Time-out", 1, "", "", "", ""], "isController": false}, {"data": ["GetActivitionStatus", 2000, 7, "401/Unauthorized", 6, "500/Internal Server Error", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Get Login Status", 2000, 6, "401/Unauthorized", 6, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 14, "400/Bad Request", 8, "401/Unauthorized", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["CreateTimeStamp", 2000, 6, "401/Unauthorized", 6, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
