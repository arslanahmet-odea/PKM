/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.95357142857142, "KoPercent": 0.04642857142857143};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7330714285714286, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.896, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.9135, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.99825, 500, 1500, "guest-login"], "isController": false}, {"data": [0.73925, 500, 1500, "Token"], "isController": false}, {"data": [0.0345, 500, 1500, "Login"], "isController": false}, {"data": [0.65375, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.77725, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [0.999, 500, 1500, "Authorize"], "isController": false}, {"data": [0.014, 500, 1500, "Debit Kart Listeleme"], "isController": false}, {"data": [0.71475, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.9, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.73175, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.891, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 28000, 13, 0.04642857142857143, 1374.7681785714312, 5, 65028, 310.0, 4826.0, 10322.850000000002, 15607.910000000014, 144.3060938401913, 252.00638920867434, 234.88928171319677], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 2000, 1, 0.05, 375.182, 21, 53168, 155.0, 800.7000000000003, 1092.5499999999984, 1781.6500000000003, 10.504201680672269, 2.965421275932248, 18.282680992318802], "isController": false}, {"data": ["FailedAttempts", 2000, 0, 0.0, 293.7904999999998, 43, 53368, 115.5, 726.0, 978.7999999999993, 1462.96, 10.502657172264582, 3.6398527675158063, 18.15709423312223], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 64.99449999999987, 15, 52925, 30.0, 42.0, 51.0, 114.0, 10.513036164844408, 13.29529475925147, 6.470773759461732], "isController": false}, {"data": ["Token", 2000, 0, 0.0, 684.9934999999994, 123, 10143, 365.5, 1508.0, 1967.7999999999993, 5665.4800000000005, 10.50194023345813, 15.014492677522172, 18.308927740415665], "isController": false}, {"data": ["Login", 2000, 1, 0.05, 4205.609999999993, 570, 56838, 3355.0, 7371.200000000002, 9361.499999999998, 14558.98, 10.4606887317461, 162.79025959506674, 19.181343026577995], "isController": false}, {"data": ["SendSmsOtp", 2000, 1, 0.05, 841.8414999999993, 24, 54250, 589.0, 1619.8000000000002, 2002.6499999999987, 2829.92, 10.487292023890053, 14.128195100992622, 18.140249997378177], "isController": false}, {"data": ["PairingAllowed", 2000, 0, 0.0, 581.8814999999988, 77, 52767, 318.5, 1244.0, 1610.6499999999987, 2568.6400000000003, 10.503870676344233, 2.6875086574871587, 18.27199592581116], "isController": false}, {"data": ["Authorize", 2000, 0, 0.0, 37.48600000000009, 19, 5041, 30.0, 43.0, 49.94999999999982, 67.0, 10.50889315082889, 12.961652392086803, 18.90627873525471], "isController": false}, {"data": ["Debit Kart Listeleme", 2000, 9, 0.45, 10175.534500000018, 171, 65028, 9948.5, 15281.9, 18991.04999999986, 38327.76000000001, 10.455384261510071, 7.482323253362713, 17.31976775814344], "isController": false}, {"data": ["GetActivitionStatus", 2000, 0, 0.0, 675.3844999999998, 101, 52685, 448.0, 1497.5000000000005, 1829.0, 2721.7300000000005, 10.502988100114482, 2.718058443877283, 18.260008937386438], "isController": false}, {"data": ["Get Login Status", 2000, 0, 0.0, 366.1859999999996, 71, 54461, 149.5, 719.7000000000003, 1107.8499999999995, 1649.7400000000002, 10.496153159866909, 2.9930487995680832, 30.691730728734797], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 11.190999999999994, 5, 282, 10.0, 14.0, 17.0, 39.0, 12.491802254770308, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 1, 0.05, 606.4489999999988, 88, 5614, 407.0, 1388.8000000000002, 1706.0, 2488.79, 10.505029282769124, 13.52668195367282, 18.417188566917037], "isController": false}, {"data": ["CreateTimeStamp", 2000, 0, 0.0, 326.2299999999994, 73, 5590, 168.5, 728.0, 1065.9499999999998, 1786.98, 10.497971267052643, 1.8863542120485215, 18.743369054867646], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 3, 23.076923076923077, 0.010714285714285714], "isController": false}, {"data": ["504/Gateway Time-out", 8, 61.53846153846154, 0.02857142857142857], "isController": false}, {"data": ["500/Internal Server Error", 2, 15.384615384615385, 0.007142857142857143], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 28000, 13, "504/Gateway Time-out", 8, "400/Bad Request", 3, "500/Internal Server Error", 2, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["CreateActivitionToken", 2000, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Login", 2000, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["SendSmsOtp", 2000, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Debit Kart Listeleme", 2000, 9, "504/Gateway Time-out", 8, "500/Internal Server Error", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
