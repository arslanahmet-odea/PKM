/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.94642857142857, "KoPercent": 0.05357142857142857};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.88375, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.99625, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.99875, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.9975, 500, 1500, "guest-login"], "isController": false}, {"data": [0.9625, 500, 1500, "Token"], "isController": false}, {"data": [0.15375, 500, 1500, "Login"], "isController": false}, {"data": [0.985, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.995, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [1.0, 500, 1500, "Authorize"], "isController": false}, {"data": [0.29375, 500, 1500, "Debit Kart Listeleme"], "isController": false}, {"data": [0.99875, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.99625, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.9975, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.9975, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5600, 3, 0.05357142857142857, 553.6742857142856, 7, 54537, 108.0, 1351.7000000000016, 1790.9499999999998, 6480.919999999998, 31.77431160386512, 55.503140771903, 51.72067117559279], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 400, 0, 0.0, 120.59250000000003, 72, 5101, 101.0, 134.0, 152.89999999999998, 283.6400000000003, 2.3158333526319446, 0.6535896864361641, 4.03068646547382], "isController": false}, {"data": ["FailedAttempts", 400, 0, 0.0, 67.24000000000001, 43, 566, 62.0, 87.80000000000007, 112.84999999999997, 161.96000000000004, 2.3181014748920634, 0.777203509388311, 4.007406605864796], "isController": false}, {"data": ["guest-login", 400, 0, 0.0, 158.6625, 15, 52489, 22.0, 37.0, 49.0, 197.80000000000018, 2.3236360256529416, 2.9385826691607027, 1.4303749695022772], "isController": false}, {"data": ["Token", 400, 0, 0.0, 505.91000000000025, 117, 52474, 155.0, 236.1000000000003, 363.74999999999994, 5154.9400000000005, 2.315873576461461, 3.310975503847245, 4.037699572214728], "isController": false}, {"data": ["Login", 400, 0, 0.0, 2888.062500000001, 691, 54537, 1653.0, 6425.400000000001, 9226.849999999979, 14382.97, 2.3061135069068097, 35.904791022876644, 4.228863794090008], "isController": false}, {"data": ["SendSmsOtp", 400, 0, 0.0, 384.7275000000001, 266, 1112, 376.0, 429.90000000000003, 459.79999999999995, 812.2600000000016, 2.3135830460634383, 3.117914651921431, 4.001950775267219], "isController": false}, {"data": ["PairingAllowed", 400, 0, 0.0, 369.8399999999998, 72, 52638, 99.0, 136.60000000000014, 157.0, 397.3300000000006, 2.317792534390247, 0.5930289492287545, 4.031872544588534], "isController": false}, {"data": ["Authorize", 400, 0, 0.0, 28.655000000000005, 20, 53, 28.0, 34.0, 38.0, 49.98000000000002, 2.3182492581602374, 2.8593250127503707, 4.170969614996754], "isController": false}, {"data": ["Debit Kart Listeleme", 400, 3, 0.75, 2584.2275000000004, 376, 53391, 1360.0, 5831.8, 6058.95, 30678.030000000086, 2.302396795063661, 1.6697773006699974, 3.8139911167056155], "isController": false}, {"data": ["GetActivitionStatus", 400, 0, 0.0, 147.37999999999997, 101, 699, 136.0, 188.0, 218.0, 345.7000000000003, 2.3167722728694384, 0.5995553245218761, 4.027971043242554], "isController": false}, {"data": ["Get Login Status", 400, 0, 0.0, 230.74249999999992, 65, 52832, 92.0, 118.90000000000003, 140.0, 245.72000000000025, 2.3167722728694384, 0.6606420934354258, 6.7745226725126555], "isController": false}, {"data": ["JSR223 Sampler", 400, 0, 0.0, 11.752499999999994, 7, 46, 11.0, 16.0, 18.0, 34.930000000000064, 2.3233525977986234, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 400, 0, 0.0, 133.51000000000005, 84, 1081, 120.0, 166.90000000000003, 203.84999999999997, 376.51000000000045, 2.3168796265190044, 2.9843400657993815, 4.062073730349965], "isController": false}, {"data": ["CreateTimeStamp", 400, 0, 0.0, 120.13750000000005, 72, 5098, 102.0, 139.90000000000003, 156.89999999999998, 212.93000000000006, 2.3179805753227787, 0.4165121346283118, 4.138642266419995], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 3, 100.0, 0.05357142857142857], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5600, 3, "500/Internal Server Error", 3, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Debit Kart Listeleme", 400, 3, "500/Internal Server Error", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
