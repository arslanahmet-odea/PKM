/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.49642857142857, "KoPercent": 0.5035714285714286};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8259464285714285, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.98725, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.98625, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [1.0, 500, 1500, "guest-login"], "isController": false}, {"data": [0.92375, 500, 1500, "Token"], "isController": false}, {"data": [0.035, 500, 1500, "Login"], "isController": false}, {"data": [0.79475, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.964, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [0.999, 500, 1500, "Authorize"], "isController": false}, {"data": [0.927, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.062, 500, 1500, "Limit Güncelleme"], "isController": false}, {"data": [0.98625, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.91675, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.98125, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 28000, 141, 0.5035714285714286, 650.5525714285718, 5, 59380, 167.0, 2662.9000000000015, 3716.850000000002, 6397.0, 200.25890615724614, 342.50811121208494, 327.6697308775095], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["CreateActivitionToken", 2000, 0, 0.0, 176.71849999999986, 75, 3192, 145.0, 282.0, 402.9499999999998, 647.99, 15.195028186777286, 4.288440572244761, 26.447451081506127], "isController": false}, {"data": ["FailedAttempts", 2000, 0, 0.0, 135.30950000000004, 44, 5343, 83.0, 250.9000000000001, 388.7999999999993, 704.8600000000001, 15.208662854361844, 5.360511550504167, 26.292013040002587], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 31.041000000000036, 15, 259, 28.0, 45.0, 54.0, 91.0, 15.319566149886636, 19.373865394632023, 9.428661867014677], "isController": false}, {"data": ["Token", 2000, 0, 0.0, 391.2120000000004, 122, 10147, 248.0, 558.6000000000004, 733.6499999999987, 5185.0, 14.900353883404732, 21.3028496926802, 25.97762473225927], "isController": false}, {"data": ["Login", 2000, 0, 0.0, 3126.5525000000025, 635, 59380, 2686.5, 3884.4000000000005, 5543.0, 11860.080000000002, 15.095023170860568, 235.0231130749317, 27.67884035078947], "isController": false}, {"data": ["SendSmsOtp", 2000, 70, 3.5, 540.5280000000002, 262, 5433, 453.0, 864.8000000000002, 1101.8999999999996, 1391.0, 15.173010249368424, 19.93804670252555, 26.246425748503565], "isController": false}, {"data": ["PairingAllowed", 2000, 0, 0.0, 249.06649999999965, 73, 52401, 156.0, 425.0, 576.0, 860.99, 15.194797301403998, 3.887731340788914, 26.43169861451939], "isController": false}, {"data": ["Authorize", 2000, 0, 0.0, 75.81049999999976, 21, 52602, 33.0, 49.0, 57.0, 85.0, 15.201958012191971, 18.75007125917818, 27.349665996355327], "isController": false}, {"data": ["GetActivitionStatus", 2000, 0, 0.0, 314.5614999999996, 101, 5244, 240.0, 574.0, 727.0, 1096.7100000000003, 15.1894888736994, 3.930873585478849, 26.408654507955497], "isController": false}, {"data": ["Limit Güncelleme", 2000, 1, 0.05, 3407.8239999999996, 1086, 32350, 2946.5, 5591.0, 6474.799999999999, 10010.78, 14.554981442398661, 3.8170865248162436, 25.845162572320064], "isController": false}, {"data": ["Get Login Status", 2000, 0, 0.0, 182.05849999999955, 72, 26725, 126.0, 276.8000000000002, 387.7999999999993, 643.95, 15.205309694145194, 4.335889092471091, 44.46154315837091], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 8.526000000000028, 5, 66, 8.0, 11.0, 12.0, 27.980000000000018, 15.319800842589046, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 70, 3.5, 284.7629999999998, 72, 52672, 197.0, 493.8000000000002, 608.7999999999993, 868.98, 15.197221947827936, 19.099524231970396, 26.643527610027885], "isController": false}, {"data": ["CreateTimeStamp", 2000, 0, 0.0, 183.76449999999997, 77, 5403, 141.0, 306.0, 412.9499999999998, 737.8800000000001, 15.20426935883596, 2.7320171504158366, 27.1460276826983], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 140, 99.29078014184397, 0.5], "isController": false}, {"data": ["500/Internal Server Error", 1, 0.7092198581560284, 0.0035714285714285713], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 28000, 141, "400/Bad Request", 140, "500/Internal Server Error", 1, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["SendSmsOtp", 2000, 70, "400/Bad Request", 70, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Limit Güncelleme", 2000, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 70, "400/Bad Request", 70, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
