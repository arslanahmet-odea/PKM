/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.65, "KoPercent": 0.35};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9114285714285715, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.82075, 500, 1500, "Limit Görüntüleme"], "isController": false}, {"data": [0.999, 500, 1500, "CreateActivitionToken"], "isController": false}, {"data": [0.9995, 500, 1500, "FailedAttempts"], "isController": false}, {"data": [0.9995, 500, 1500, "guest-login"], "isController": false}, {"data": [0.995, 500, 1500, "Token"], "isController": false}, {"data": [0.05275, 500, 1500, "Login"], "isController": false}, {"data": [0.926, 500, 1500, "SendSmsOtp"], "isController": false}, {"data": [0.99975, 500, 1500, "PairingAllowed"], "isController": false}, {"data": [0.999, 500, 1500, "Authorize"], "isController": false}, {"data": [0.99725, 500, 1500, "GetActivitionStatus"], "isController": false}, {"data": [0.9985, 500, 1500, "Get Login Status"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.9735, 500, 1500, "ValidateOTP"], "isController": false}, {"data": [0.9995, 500, 1500, "CreateTimeStamp"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 28000, 98, 0.35, 340.4386428571449, 5, 55085, 134.0, 525.0, 2160.0, 2861.9900000000016, 141.85043897644775, 243.5560559372008, 230.8059119495063], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Limit Görüntüleme", 2000, 0, 0.0, 565.1950000000004, 270, 52799, 468.0, 627.0, 749.0, 1049.9, 10.258725045651326, 3.386846943989926, 16.903663919679314], "isController": false}, {"data": ["CreateActivitionToken", 2000, 0, 0.0, 130.17050000000006, 73, 844, 118.0, 180.0, 212.0, 296.99, 12.97723792468011, 3.662521250227101, 22.587155079209815], "isController": false}, {"data": ["FailedAttempts", 2000, 0, 0.0, 110.49400000000009, 43, 52747, 74.0, 124.0, 150.0, 257.93000000000006, 12.985579513949759, 4.655476089895921, 22.44898544073057], "isController": false}, {"data": ["guest-login", 2000, 0, 0.0, 31.731000000000016, 15, 5018, 25.0, 43.0, 56.0, 95.96000000000004, 13.065746838089266, 16.523576323560153, 8.042082014509512], "isController": false}, {"data": ["Token", 2000, 0, 0.0, 243.48099999999988, 123, 52634, 201.0, 281.0, 321.9499999999998, 476.8800000000001, 10.27448280822164, 14.689299639879376, 17.913164445987043], "isController": false}, {"data": ["Login", 2000, 0, 0.0, 2365.618000000001, 588, 55085, 2285.5, 3023.2000000000007, 3371.95, 4058.7700000000004, 12.906889697720644, 200.95480229065026, 23.66669182501807], "isController": false}, {"data": ["SendSmsOtp", 2000, 49, 2.45, 434.20750000000066, 259, 1586, 401.5, 524.0, 674.9499999999998, 1108.98, 12.955297745130427, 17.15324437092313, 22.409578094534805], "isController": false}, {"data": ["PairingAllowed", 2000, 0, 0.0, 134.56150000000028, 75, 605, 120.0, 188.0, 230.0, 343.98, 12.976816916578532, 3.3202402657652104, 22.57401575912757], "isController": false}, {"data": ["Authorize", 2000, 0, 0.0, 64.43599999999998, 20, 52771, 32.0, 48.0, 57.0, 84.97000000000003, 10.283939571571077, 12.684194998920185, 18.501565528941576], "isController": false}, {"data": ["GetActivitionStatus", 2000, 0, 0.0, 216.77149999999986, 105, 52496, 170.0, 269.8000000000002, 307.9499999999998, 434.95000000000005, 12.974038948064923, 3.3575393762082073, 22.556405647923505], "isController": false}, {"data": ["Get Login Status", 2000, 0, 0.0, 161.19399999999996, 71, 52490, 110.0, 165.0, 193.0, 263.95000000000005, 12.984905047881837, 3.702726830060055, 37.969954654276904], "isController": false}, {"data": ["JSR223 Sampler", 2000, 0, 0.0, 8.795000000000012, 5, 64, 8.0, 11.0, 13.0, 33.99000000000001, 13.064551951190833, 0.0, 0.0], "isController": false}, {"data": ["ValidateOTP", 2000, 49, 2.45, 167.00900000000013, 68, 5179, 151.0, 227.9000000000001, 267.0, 387.95000000000005, 12.976480129764802, 16.43042883211679, 22.751324259935117], "isController": false}, {"data": ["CreateTimeStamp", 2000, 0, 0.0, 132.47699999999983, 74, 5118, 118.5, 180.0, 206.0, 298.98, 12.985663827134843, 2.333361468938292, 23.185281379045037], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 98, 100.0, 0.35], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 28000, 98, "400/Bad Request", 98, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["SendSmsOtp", 2000, 49, "400/Bad Request", 49, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["ValidateOTP", 2000, 49, "400/Bad Request", 49, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
